﻿using System;
using System.Threading.Tasks;

namespace NumericalPi
{
    public class PiCalc
    {
        private int insideCirlce = 0;
        /// <summary>
        /// Executes the calculation of an 
        /// approximate value of pi.
        /// </summary>
        /// <param name="iterations">Number of iterations to perform</param>
        /// <returns>Approximate value of pi</returns>
        public double Calculate(int iterations, int noOfParallels)
        {
            double iterationsperparallel = iterations / noOfParallels;

            Parallel.For(0, noOfParallels, (i => Iterate(iterationsperparallel, i)));

            return (double)insideCirlce / iterationsperparallel;
        }

        /// <summary>
        /// Perform a number of "dart-throwing" simulations.
        /// </summary>
        /// <param name="iterations">Number of dart-throws to perform</param>
        /// <returns>Number of throws within the unit circle</returns>
        public void Iterate(double iterations, int j)
        {
            Random _generator = new Random(Guid.NewGuid().GetHashCode());

            Console.WriteLine("iteration: " + j +" iterations: "+ iterations);
            for (int i = 0; i < iterations; i++)
            {
                double x = _generator.NextDouble();
                double y = _generator.NextDouble();

                if (x * x + y * y < 1.0)
                {
                    insideCirlce++;
                }
            }
        }
    }
}